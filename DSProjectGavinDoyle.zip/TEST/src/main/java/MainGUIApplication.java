import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.jmdns.JmDNS;
import javax.jmdns.ServiceEvent;
import javax.jmdns.ServiceInfo;
import javax.jmdns.ServiceListener;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.FlowLayout;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import ds.examples.maths.CalculateRequest;
import ds.examples.maths.CalculateRequest.Operation;
import ds.examples.maths.CalculateResponse;
import ds.examples.maths.MathServiceGrpc;
import ds.examples.maths.MathServiceGrpc.MathServiceBlockingStub;
import ds.examples.maths.MathServiceGrpc.MathServiceStub;

import ds.examples.lights.LuminateRequest;
import ds.examples.lights.LuminateRequest.Operation2;
import ds.examples.lights.LuminateResponse;
import ds.examples.lights.LightServiceGrpc;
import ds.examples.lights.LightServiceGrpc.LightServiceBlockingStub;
import ds.examples.lights.LightServiceGrpc.LightServiceStub;

import ds.project.users.LoginRequest;
import ds.project.users.LoginRequest.Operation3;
import ds.project.users.LoginResponse;
import ds.project.users.UserServiceGrpc;
import ds.project.users.UserServiceGrpc.UserServiceBlockingStub;
import ds.project.users.UserServiceGrpc.UserServiceStub;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;


import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.awt.event.ActionEvent;

public class MainGUIApplication {

	private static MathServiceBlockingStub blockingStub;
	private static MathServiceStub asyncStub;
	private ServiceInfo mathServiceInfo;
	
	private static LightServiceBlockingStub blockingStub2;
	private static LightServiceStub asyncStub2;
	private ServiceInfo lightServiceInfo;
	
	private static UserServiceBlockingStub blockingStub3;
	private static UserServiceStub asyncStub3;
	private ServiceInfo userServiceInfo;
	
	
	private JFrame frame;
	private JFrame frame2;
	private JFrame frame3;
	private JTextField textNumber1;
	private JTextField textNumber2;
	private JTextField textNumber3;
	private JTextArea textResponse;
	private JTextArea textResponse2;
	private JTextArea textResponse3;

	
	// Launch the application.
	 
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainGUIApplication window = new MainGUIApplication();		//????????????
					window.frame.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				try {

					MainGUIApplication window2 = new MainGUIApplication();
					window2.frame2.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				try {

					MainGUIApplication window3 = new MainGUIApplication();
					window3.frame3.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				
			}
		});
	}

	
	 //Create the application.
	 
	public MainGUIApplication() {
		
		
		String math_service_type = "_maths._tcp.local.";
		discoverMathService(math_service_type);
		
		String host = mathServiceInfo.getHostAddresses()[0];		
		int port = mathServiceInfo.getPort();
		
		String light_service_type = "_lights._tcp.local.";
		discoverLightService(light_service_type);
		
		String host2 = lightServiceInfo.getHostAddresses()[0];
		int port2 = lightServiceInfo.getPort();
		
		String user_service_type = "_users._tcp.local.";
		discoverUserService(user_service_type);
		
		String host3 = userServiceInfo.getHostAddresses()[0];
		int port3 = userServiceInfo.getPort();
	
		
		ManagedChannel channel = ManagedChannelBuilder
				.forAddress(host, port)
				.usePlaintext()
				.build();

		//stubs -- generate from proto
		blockingStub = MathServiceGrpc.newBlockingStub(channel);

		asyncStub = MathServiceGrpc.newStub(channel);
		
		
		
		
		ManagedChannel channel2 = ManagedChannelBuilder
				.forAddress(host2, port2)
				.usePlaintext()
				.build();

		//stubs -- generate from proto
		blockingStub2 = LightServiceGrpc.newBlockingStub(channel2);

		asyncStub2 = LightServiceGrpc.newStub(channel2);
		
		
		ManagedChannel channel3 = ManagedChannelBuilder
				.forAddress(host3, port3)
				.usePlaintext()
				.build();

		//stubs -- generate from proto
		blockingStub3 = UserServiceGrpc.newBlockingStub(channel3);

		asyncStub3 = UserServiceGrpc.newStub(channel3);

		
		initialize();
		initialize2();
		initialize3();
		
	}

	
	
	private void discoverMathService(String service_type) {
		
		
		try {
			// Create a JmDNS instance
			JmDNS jmdns = JmDNS.create(InetAddress.getLocalHost());

				
			jmdns.addServiceListener(service_type, new ServiceListener() {
				
		// @Override
				public void serviceResolved(ServiceEvent event) {
					System.out.println("Math Service resolved: " + event.getInfo());

					mathServiceInfo = event.getInfo();

					int port = mathServiceInfo.getPort();
					
					System.out.println("resolving " + service_type + " with properties ...");
					System.out.println("\t port: " + port);
					System.out.println("\t type:"+ event.getType());
					System.out.println("\t name: " + event.getName());
					System.out.println("\t description/properties: " + mathServiceInfo.getNiceTextString());
					System.out.println("\t host: " + mathServiceInfo.getHostAddresses()[0]);
				
					
				}
				
				@Override
				public void serviceRemoved(ServiceEvent event) {
					System.out.println("Math Service removed: " + event.getInfo());

					
				}
				
				@Override
				public void serviceAdded(ServiceEvent event) {
					System.out.println("Math Service added: " + event.getInfo());

					
				}
			});
			
			// Wait a bit
			Thread.sleep(2000);
			
			jmdns.close();

		} catch (UnknownHostException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	
	
	 //Initialize the contents of the frame.
	 
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("Client - Service Controller");
		frame.setBounds(100, 100, 500, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		BoxLayout bl = new BoxLayout(frame.getContentPane(), BoxLayout.Y_AXIS);
		
		frame.getContentPane().setLayout(bl);
		
		JPanel panel_service_1 = new JPanel();
		frame.getContentPane().add(panel_service_1);
		panel_service_1.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		JLabel lblNewLabel_1 = new JLabel("Current Temperature");
		panel_service_1.add(lblNewLabel_1);
		
		textNumber1 = new JTextField();
		panel_service_1.add(textNumber1);
		textNumber1.setColumns(10);
		
		
		JComboBox comboOperation = new JComboBox();
		comboOperation.setModel(new DefaultComboBoxModel(new String[] {"INCREASE", "DECREASE"}));
		panel_service_1.add(comboOperation);
	
		
		JButton btnCalculate = new JButton("ADJUST");
		btnCalculate.addActionListener(new ActionListener() {
			/**
			 *
			 */
			public void actionPerformed(ActionEvent e) {
				
				int num1 = 0;		//initializes num1
				
				try {
					
					 num1 = Integer.parseInt(textNumber1.getText());
						
					int index = comboOperation.getSelectedIndex();
					Operation operation = Operation.forNumber(index);
					
					CalculateRequest req = CalculateRequest.newBuilder().setNumber1(num1).setOperation(operation).build();
	
					CalculateResponse response = blockingStub.calculate(req);
	
					textResponse.append("New Temperature: "+ response.getResult() + "°C "+ "\nmes: " + response.getMessage() + "\n");
					
			
					// num1 = (int)(response.getResult());    //trying to get adjustments to update incrementally
					
					System.out.println("res: " + response.getResult() + " mes: " + response.getMessage());
					
				
				} catch (Exception f) {		//throws an error if input is not an int
					
					textResponse.append(" ERROR: User input is not a valid temperatre! \n (Must be whole number) \n\n");
					
				}
			}
		});
		panel_service_1.add(btnCalculate);
		
		textResponse = new JTextArea(5, 30);
		textResponse .setLineWrap(true);
		textResponse.setWrapStyleWord(true);
		
		JScrollPane scrollPane = new JScrollPane(textResponse);
		
		//textResponse.setSize(new Dimension(15, 30));
		panel_service_1.add(scrollPane);
		
		
		JPanel panel_service_2 = new JPanel();
		frame.getContentPane().add(panel_service_2);
		
		JPanel panel_service_3 = new JPanel();
		frame.getContentPane().add(panel_service_3);
		
	}
	
	
private void discoverLightService(String service_type) {
		
		
		try {
			// Create a JmDNS instance
			JmDNS jmdns2 = JmDNS.create(InetAddress.getLocalHost());

				
			jmdns2.addServiceListener(service_type, new ServiceListener() {
				
				@Override
				public void serviceResolved(ServiceEvent event2) {
					System.out.println("Light Service resolved: " + event2.getInfo());

					lightServiceInfo = event2.getInfo();

					int port2 = lightServiceInfo.getPort();
					
					System.out.println("resolving " + service_type + " with properties ...");
					System.out.println("\t port: " + port2);
					System.out.println("\t type:"+ event2.getType());
					System.out.println("\t name: " + event2.getName());
					System.out.println("\t description/properties: " + lightServiceInfo.getNiceTextString());
					System.out.println("\t host: " + lightServiceInfo.getHostAddresses()[0]);
				
					
				}
				
				@Override
				public void serviceRemoved(ServiceEvent event) {
					System.out.println("Light Service removed: " + event.getInfo());

					
				}
				
				@Override
				public void serviceAdded(ServiceEvent event) {
					System.out.println("Light Service added: " + event.getInfo());

					
				}
			});
			
			// Wait a bit
			Thread.sleep(2000);
			
			jmdns2.close();

		} catch (UnknownHostException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	
	
	 //Initialize the contents of the frame.
	 
	private void initialize2() {
		frame2 = new JFrame();
		frame2.setTitle("Client - Service Controller");
		frame2.setBounds(100, 100, 500, 300);
		frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		BoxLayout b2 = new BoxLayout(frame2.getContentPane(), BoxLayout.Y_AXIS);
		
		frame2.getContentPane().setLayout(b2);
		
		JPanel panel_service_4 = new JPanel();
		frame2.getContentPane().add(panel_service_4);
		panel_service_4.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		JLabel lblNewLabel_2 = new JLabel("Current Light Level");
		panel_service_4.add(lblNewLabel_2);
		
		textNumber2 = new JTextField();
		panel_service_4.add(textNumber2);
		textNumber2.setColumns(10);
		
		
		JComboBox comboOperation2 = new JComboBox();
		comboOperation2.setModel(new DefaultComboBoxModel(new String[] {"INCREASE", "DECREASE"}));
		panel_service_4.add(comboOperation2);
	
		
		JButton btnLuminate2 = new JButton("ADJUST");
		btnLuminate2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int num2 = 0;		//initializes num2
				
				try {
					
					 num2 = Integer.parseInt(textNumber2.getText());
						
					int index = comboOperation2.getSelectedIndex();
					Operation2 operation2 = Operation2.forNumber(index);
					
					LuminateRequest req = LuminateRequest.newBuilder().setNumber2(num2).setOperation2(operation2).build();
	
					LuminateResponse response2 = blockingStub2.luminate(req);
	
					textResponse2.append("New Temperature: "+ response2.getResult2() + "LUMINS "+ "\nmes: " + response2.getMessage() + "\n");
					
			
					// num1 = (int)(response2.getResult());    //trying to get adjustments to update incrementally
					
					System.out.println("res: " + response2.getResult2() + " mes: " + response2.getMessage());
					
				
				} catch (Exception h) {		//throws an error if input is not an int
					
					textResponse2.append(" ERROR: User input is not a valid light level! \n (Must be whole number) \n\n");
					
				}
			}
		});
		panel_service_4.add(btnLuminate2);
		
		textResponse2 = new JTextArea(5, 30);
		textResponse2 .setLineWrap(true);
		textResponse2.setWrapStyleWord(true);
		
		JScrollPane scrollPane2 = new JScrollPane(textResponse2);
		
		//textResponse2.setSize(new Dimension(15, 30));
		panel_service_4.add(scrollPane2);
		
		
		JPanel panel_service_5 = new JPanel();
		frame2.getContentPane().add(panel_service_5);
		
		JPanel panel_service_6 = new JPanel();
		frame2.getContentPane().add(panel_service_6);
		
	}
	

	
	
private void discoverUserService(String service_type) {
		
		
		try {
			// Create a JmDNS instance
			JmDNS jmdns2 = JmDNS.create(InetAddress.getLocalHost());

				
			jmdns2.addServiceListener(service_type, new ServiceListener() {
				
				@Override
				public void serviceResolved(ServiceEvent event2) {
					System.out.println("Light Service resolved: " + event2.getInfo());

					lightServiceInfo = event2.getInfo();

					int port2 = lightServiceInfo.getPort();
					
					System.out.println("resolving " + service_type + " with properties ...");
					System.out.println("\t port: " + port2);
					System.out.println("\t type:"+ event2.getType());
					System.out.println("\t name: " + event2.getName());
					System.out.println("\t description/properties: " + lightServiceInfo.getNiceTextString());
					System.out.println("\t host: " + lightServiceInfo.getHostAddresses()[0]);
				
					
				}
				
				@Override
				public void serviceRemoved(ServiceEvent event) {
					System.out.println("Light Service removed: " + event.getInfo());

					
				}
				
				@Override
				public void serviceAdded(ServiceEvent event) {
					System.out.println("Light Service added: " + event.getInfo());

					
				}
			});
			
			// Wait a bit
			Thread.sleep(2000);
			
			jmdns2.close();

		} catch (UnknownHostException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	
	
	 //Initialize the contents of the frame.
	 
	private void initialize3() {
		frame3 = new JFrame();
		frame3.setTitle("Client - Service Controller");
		frame3.setBounds(100, 100, 500, 300);
		frame3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		BoxLayout b3 = new BoxLayout(frame3.getContentPane(), BoxLayout.Y_AXIS);
		
		frame3.getContentPane().setLayout(b3);
		
		JPanel panel_service_7 = new JPanel();
		frame3.getContentPane().add(panel_service_7);
		panel_service_7.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		JLabel lblNewLabel_3 = new JLabel("Username: ");
		panel_service_7.add(lblNewLabel_3);
		
		textNumber3 = new JTextField();
		panel_service_7.add(textNumber3);
		textNumber3.setColumns(10);
		
		
		JComboBox comboOperation3 = new JComboBox();
		comboOperation3.setModel(new DefaultComboBoxModel(new String[] {"LOGIN", "LOGOUT"}));
		panel_service_7.add(comboOperation3);
	
		
		JButton btnLuminate3 = new JButton("CONFIRM");
		btnLuminate3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String num3 = "";		//initializes num2
				
				try {
					
					 num3 = textNumber3.getText();
						
					int index = comboOperation3.getSelectedIndex();
					Operation3 operation3 = Operation3.forNumber(index);
					
					LoginRequest req = LoginRequest.newBuilder().setUsername(num3).setOperation3(operation3).build();
	
					LoginResponse response3 = blockingStub3.login(req);
	
					textResponse3.append("Operation: "+ response3.getResult3() + "LUMINS "+ "\nmes: " + response3.getMessage() + "\n");
					
			
					// num1 = (int)(response2.getResult());    //trying to get adjustments to update incrementally
					
					System.out.println("res: " + response3.getResult3() + " mes: " + response3.getMessage());
					
				
				} catch (Exception l) {		//throws an error if input is not an int
					
					textResponse3.append(" ERROR: User input is not a valid light level! \n (Must be whole number) \n\n");
					
				}
			}
		});
		panel_service_7.add(btnLuminate3);
		
		textResponse3 = new JTextArea(5, 30);
		textResponse3 .setLineWrap(true);
		textResponse3.setWrapStyleWord(true);
		
		JScrollPane scrollPane3 = new JScrollPane(textResponse2);
		
		//textResponse3.setSize(new Dimension(15, 30));
		panel_service_7.add(scrollPane3);
		
		
		JPanel panel_service_8 = new JPanel();
		frame3.getContentPane().add(panel_service_8);
		
		JPanel panel_service_9 = new JPanel();
		frame3.getContentPane().add(panel_service_9);
		
	}
	
	
}
