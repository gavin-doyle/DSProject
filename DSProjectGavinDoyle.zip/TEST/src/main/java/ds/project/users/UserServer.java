package ds.project.users;

import static io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Properties;

import javax.jmdns.JmDNS;
import javax.jmdns.ServiceInfo;

import ds.project.users.LoginRequest.Operation3;
import ds.project.users.UserServiceGrpc.UserServiceImplBase;

import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.stub.StreamObserver;

public class UserServer extends UserServiceImplBase {


	public static void main(String[] args) {
		UserServer userserver = new UserServer();

		Properties prop = userserver.getProperties();
		
		userserver.registerService(prop);
		
		int port = Integer.valueOf( prop.getProperty("service_port") );// #.50053;

		try {

			Server server = ServerBuilder.forPort(port)
					.addService(userserver)
					.build()
					.start();

			System.out.println("User Server started, listening on " + port);

			server.awaitTermination();


		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}

	
	private Properties getProperties() {
		
		Properties prop = null;		
		
		 try (InputStream input = new FileInputStream("src/main/resources/user.properties")) {

	            prop = new Properties();

	            // load a properties file
	            prop.load(input);

	            // get the property value and print it out
	            System.out.println("User Service properies ...");
	            System.out.println("\t service_type: " + prop.getProperty("service_type"));
	            System.out.println("\t service_name: " +prop.getProperty("service_name"));
	            System.out.println("\t service_description: " +prop.getProperty("service_description"));
		        System.out.println("\t service_port: " +prop.getProperty("service_port"));

	        } catch (IOException ex) {
	            ex.printStackTrace();
	        }
	
		 return prop;
	}
	
	
	private  void registerService(Properties prop) {
		
		 try {
	            // Create a JmDNS instance
	            JmDNS jmdns = JmDNS.create(InetAddress.getLocalHost());
	            
	            String service_type = prop.getProperty("service_type") ;//"_http._tcp.local.";
	            String service_name = prop.getProperty("service_name")  ;// "example";
	           // int service_port = 1234;
	            int service_port = Integer.valueOf( prop.getProperty("service_port") );// #.50053;

	            
	            String service_description_properties = prop.getProperty("service_description")  ;//"path=index.html";
	            
	            // Register a service
	            ServiceInfo serviceInfo = ServiceInfo.create(service_type, service_name, service_port, service_description_properties);
	            jmdns.registerService(serviceInfo);
	            
	            System.out.printf("registrering service with type %s and name %s \n", service_type, service_name);
	            
	            // Wait a bit
	            Thread.sleep(1000);

	            // Unregister all services
	            //jmdns.unregisterAllServices();

	        } catch (IOException e) {
	            System.out.println(e.getMessage());
	        } catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    
	}
	
	public void login(LoginRequest request, StreamObserver<LoginResponse> responseObserver) {
		String username = request.getUsername();

		System.out.println("receiving " + request.getOperation3() + " method for " + request.getUsername());
		
		System.out.println("username = " + username);

		float value = Float.NaN;
		String msg= "";

		if(	request.getOperation3()==Operation3.LOGIN)
			
			if(username.equals("Gavin")) {
				// return Success response
				msg= (username + ".....Successfully logged in");
			}
			else {
				// return Success response
				msg= (username + "... Sorry Login Failed");
			}
		
		
		else if(	request.getOperation3()==Operation3.LOGOUT)
			
			if(username.equals("Gavin")) {
				// return Success response
				msg = (username + ".....Successfully logged out");
			}
			else {
				// return Success response
				msg = (username + ".....User not Logged in");
			}
		
		
		else {
			value = Float.NaN;
			msg = "INVALID OPERATION";
		}		

		LoginResponse reply = LoginResponse.newBuilder().setResult3(value).setMessage(msg).build();

		//responseObserver.onNext(reply);
		responseObserver.onNext(reply);

		responseObserver.onCompleted();
	}

}
